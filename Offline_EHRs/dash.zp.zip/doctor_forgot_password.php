<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$host = "localhost";
$user = "root";
$pass = "sathwik@1804";
$dbname = "ehr_system";

$conn = new mysqli($host, $user, $pass, $dbname);
$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];

    $stmt = $conn->prepare("SELECT doctor_id FROM doctors WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $token = bin2hex(random_bytes(16));
        $update = $conn->prepare("UPDATE doctors SET reset_token = ? WHERE email = ?");
        $update->bind_param("ss", $token, $email);
        $update->execute();

        $resetLink = "http://localhost/ehr/dr_reset_password.php?token=$token";

        $mail = new PHPMailer(true);
        try {
            // SMTP server configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'ehrsecure@gmail.com'; // Your Gmail
            $mail->Password = 'ibat rxak rwup hkkn'; // Your App Password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Email details
            $mail->setFrom('ehrsecure@gmail.com', 'EHR System');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Request';
            $mail->Body = "
                <p>Hello Doctor,</p>
                <p>You requested to reset your password. Click the link below:</p>
                <p><a href='$resetLink'>$resetLink</a></p>
                <p>This link will expire in 15 minutes. If you did not request this, please ignore this email.</p>
            ";

            $mail->send();
            $message = "<p class='success'>✅ A password reset link has been sent to your email address.</p>";
        } catch (Exception $e) {
            $message = "<p class='error'>❌ Message could not be sent. Mailer Error: {$mail->ErrorInfo}</p>";
        }

    } else {
        $message = "<p class='error'>❌ Email not found.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Forgot Password</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f7f8;
    }
    .container {
      width: 400px;
      margin: 80px auto;
      padding: 30px;
      background: white;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      color: #333;
    }
    label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
    }
    input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    button {
      width: 100%;
      padding: 12px;
      margin-top: 20px;
      background-color: #007bff;
      border: none;
      color: white;
      font-size: 16px;
      border-radius: 5px;
    }
    button:hover {
      background-color: #0056b3;
    }
    .success {
      color: green;
      font-size: 14px;
      margin-top: 15px;
      text-align: center;
    }
    .error {
      color: red;
      font-size: 14px;
      margin-top: 15px;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Forgot Password</h2>
    <?php echo $message; ?>
    <form method="POST" action="">
      <label for="email">Registered Email Address</label>
      <input type="email" name="email" required>
      <button type="submit">Send Reset Link</button>
    </form>
  </div>
</body>
</html>
